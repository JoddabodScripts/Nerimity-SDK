"""nerimity-sdk — A fully-featured Python SDK for building Nerimity bots."""
from nerimity_sdk.bot import Bot
from nerimity_sdk.models import (
    User, UserBadge, Message, MessageAttachment,
    Server, Channel, Member, Role, BotCommand, Permissions,
)
from nerimity_sdk.context.ctx import Context
from nerimity_sdk.commands.router import CommandRouter
from nerimity_sdk.commands.builders import MessageBuilder, Embed
from nerimity_sdk.commands.prefix import PrefixResolver, MemoryPrefixStore
from nerimity_sdk.events.emitter import EventEmitter
from nerimity_sdk.events.payloads import (
    ReadyEvent, MessageCreatedEvent, MessageUpdatedEvent, MessageDeletedEvent,
    ReactionAddedEvent, ReactionRemovedEvent, MemberJoinedEvent, MemberLeftEvent,
    PresenceUpdatedEvent, TypingEvent,
)
from nerimity_sdk.cache.store import Cache
from nerimity_sdk.permissions.checker import (
    has_permission, resolve_permissions, role_position, can_target,
)
from nerimity_sdk.plugins.manager import PluginBase, PluginManager, listener
from nerimity_sdk.storage import JsonStore, SqliteStore, RedisStore, MemoryStore
from nerimity_sdk.scheduler import Scheduler, CronJob

__version__ = "0.2.0"
__all__ = [
    "Bot",
    # Models
    "User", "UserBadge", "Message", "MessageAttachment",
    "Server", "Channel", "Member", "Role", "BotCommand", "Permissions",
    # Context
    "Context",
    # Commands
    "CommandRouter", "MessageBuilder", "Embed",
    "PrefixResolver", "MemoryPrefixStore",
    # Events
    "EventEmitter",
    "ReadyEvent", "MessageCreatedEvent", "MessageUpdatedEvent", "MessageDeletedEvent",
    "ReactionAddedEvent", "ReactionRemovedEvent", "MemberJoinedEvent", "MemberLeftEvent",
    "PresenceUpdatedEvent", "TypingEvent",
    # Cache
    "Cache",
    # Permissions
    "has_permission", "resolve_permissions", "role_position", "can_target",
    # Plugins
    "PluginBase", "PluginManager", "listener",
    # Storage
    "JsonStore", "SqliteStore", "RedisStore", "MemoryStore",
    # Scheduler
    "Scheduler", "CronJob",
]
